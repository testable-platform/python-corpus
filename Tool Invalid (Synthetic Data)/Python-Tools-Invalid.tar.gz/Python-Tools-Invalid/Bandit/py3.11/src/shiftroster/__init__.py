"""Shift roster scheduling toolkit."""
